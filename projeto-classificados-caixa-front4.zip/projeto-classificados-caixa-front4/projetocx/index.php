<!DOCTYPE html>
<html lang="pt-BR">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <title>Alimentation</title>
  </head>
  <body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
      <div class="container-fluid">
        <a class="navbar-brand" href="index.php">Alimentation</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNavDropdown">
          <ul class="navbar-nav">
            <li class="nav-item">
              <a class="nav-link" aria-current="page" href="index.php">Início</a>
            </li>            
            <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                Produtos
              </a>
              <ul class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
                <li><a class="dropdown-item" href="?page=listar-produtos">Listar</a></li>
                <li><a class="dropdown-item" href="?page=cadastrar-produtos">Cadastrar</a></li>
              </ul>
            </li>
          </ul>
        </div>
      </div>
    </nav>

    <div class="container">
      <div class="row">
        <div class="col-lg-12 mt-5">
          <?php  
            
            include('conf.php'); 
            switch (@$_REQUEST ["page"]){
              case "listar-produtos":
                include("pages/listar-produtos.php");
              break;
              case "cadastrar-produtos":
                include("pages/cadastrar-produtos.php");
              break;
              case "editar-produtos":
                include("pages/editar-produtos.php");
              break;
              case "salvar-produtos":
                include("pages/salvar-produtos.php");
              break;
              
              default:
                include("pages/main.php");
            }
              
              
                     
            
          ?>         
        </div>        
      </div>
    </div>
     <script src="js/bootstrap.bundle.min.js"></script>
  </body>
</html>