# projeto-classificados-caixa
Repositório para armazenar os arquivos do projeto de classificados da caixa feita pelos estagiários vespertinos.
